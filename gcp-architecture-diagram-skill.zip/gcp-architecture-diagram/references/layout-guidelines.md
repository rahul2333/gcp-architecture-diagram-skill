# Layout and cloud boundaries

Arrange request flow left to right, leaving at least 150 pixels between icons and room for labels below. Use descriptive IDs such as `svc-cloud-run`, `grp-project` and numbered flow labels for nontechnical audiences.

A project can contain a global VPC, regional subnets, and zonal resources. Place services according to their actual scope; a regional service does not automatically belong inside a VPC or zone. Cloud Run, Cloud SQL and Cloud Storage can appear in a separate managed services area. Document private connectivity when relevant rather than implying it through nesting.

Use Google blue arrows for primary traffic and explicit connection labels. Keep container padding at least 40 pixels. Preserve original icon dimensions. The generator uses plain editable containers so service icons remain the authoritative visual assets.
