"""Extract modern GCP image icons without evaluating upstream JavaScript."""
import base64
import binascii
import hashlib
import json
import re
import urllib.request
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
URL = 'https://raw.githubusercontent.com/jgraph/drawio/dev/src/main/webapp/js/diagramly/sidebar/Sidebar-GCP2.js'


def main():
    raw = urllib.request.urlopen(URL, timeout=30).read()
    source = raw.decode('utf-8')
    catalog = {}
    sections = re.split(r'Sidebar\.prototype\.(addGCP2Icons\w+Palette)\s*=\s*function\(\)', source)
    pattern = re.compile(r"this\.createVertexTemplateEntry\(n\s*\+\s*'([^']+)'\s*,\s*s\s*\*\s*([\d.]+)\s*,\s*s\s*\*\s*([\d.]+)\s*,\s*'([^']+)'", re.S)
    for category, body in zip(sections[1::2], sections[2::2]):
        prefix = re.search(r"var n = '([^']+)';", body)
        if not prefix:
            raise ValueError(f'Unsupported style prefix: {category}')
        matches = list(pattern.finditer(body))
        if len(matches) != body.count('this.createVertexTemplateEntry('):
            raise ValueError(f'Extraction coverage mismatch: {category}')
        entries = []
        for match in matches:
            suffix, width, height, label = match.groups()
            name = label.replace('\\n', ' ').strip()
            style = (prefix[1] + suffix).replace('\\/', '/')
            encoded = re.search(r'image=data:image/svg\+xml,([^;]+)', style)
            if not encoded:
                raise ValueError(f'Missing SVG: {name}')
            try:
                ET.fromstring(base64.b64decode(encoded[1], validate=True))
            except (binascii.Error, ET.ParseError) as error:
                print(f'Excluded invalid upstream SVG {name}: {error}')
                continue
            if name in catalog:
                name = name + ' (' + category.removeprefix('addGCP2Icons').removesuffix('Palette') + ')'
            catalog[name] = dict(width=float(width), height=float(height), style=style)
            entries.append(f'### {name}\n\n- Width: {width}\n- Height: {height}\n- Style: `{style}`\n')
        filename = re.sub(r'(?<!^)(?=[A-Z])', '-', category.removeprefix('addGCP2Icons').removesuffix('Palette')).lower()
        (ROOT / 'references' / f'gcp-icons-{filename}.md').write_text('\n'.join(entries), encoding='utf-8')
    if not catalog:
        raise ValueError('No icons extracted; upstream format may have changed')
    (ROOT / 'references/icons.json').write_text(json.dumps(catalog, indent=2), encoding='utf-8')
    (ROOT / 'references/source.json').write_text(json.dumps(dict(url=URL, sha256=hashlib.sha256(raw).hexdigest(), count=len(catalog)), indent=2), encoding='utf-8')
    print(f'Extracted and validated {len(catalog)} SVG icons')


if __name__ == '__main__':
    main()
