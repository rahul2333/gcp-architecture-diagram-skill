"""Build editable Draw.io XML from a JSON architecture and saved icon catalog."""
import argparse
import json
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]


def generate(spec, output):
    icons = json.loads((ROOT / 'references/icons.json').read_text(encoding='utf-8'))
    tree = ET.parse(ROOT / 'templates/base.drawio.xml')
    root = tree.find('.//root')
    ids = {'0', '1'}
    nodes = spec.get('containers', []) + spec['nodes']
    for node in nodes:
        if node['id'] in ids:
            raise ValueError(f'Duplicate ID: {node["id"]}')
        ids.add(node['id'])
    parents = {n['id']: n.get('parent', '1') for n in nodes}
    for node in nodes:
        parent = parents[node['id']]
        seen = {node['id']}
        while parent != '1':
            if parent not in parents or parent in seen:
                raise ValueError(f'Invalid parent hierarchy: {node["id"]}')
            seen.add(parent)
            parent = parents[parent]
        if 'service' in node:
            icon = icons[node['service']]
            style, width, height = icon['style'], icon['width'], icon['height']
        else:
            style = 'rounded=1;whiteSpace=wrap;html=1;verticalAlign=top;align=left;spacing=12;fillColor=#F6F6F6;strokeColor=#999999;'
            width, height = node.get('width', 800), node.get('height', 400)
        cell = ET.SubElement(root, 'mxCell', id=node['id'], value=node.get('label', node.get('service', '')), style=style, vertex='1', parent=node.get('parent', '1'))
        ET.SubElement(cell, 'mxGeometry', x=str(node.get('x', 0)), y=str(node.get('y', 0)), width=str(width), height=str(height), attrib={'as': 'geometry'})
    for index, edge in enumerate(spec.get('edges', []), 1):
        identifier = f'edge-{index}'
        if identifier in ids or any(edge[k] not in parents for k in ('source', 'target')):
            raise ValueError(f'Invalid edge: {edge}')
        ids.add(identifier)
        cell = ET.SubElement(root, 'mxCell', id=identifier, value=edge.get('label', ''), source=edge['source'], target=edge['target'], parent='1', edge='1', style='edgeStyle=orthogonalEdgeStyle;rounded=0;html=1;endArrow=block;strokeColor=#4284F3;')
        ET.SubElement(cell, 'mxGeometry', relative='1', attrib={'as': 'geometry'})
    Path(output).parent.mkdir(parents=True, exist_ok=True)
    tree.write(output, encoding='utf-8', xml_declaration=True)
    print(f'Saved {output}')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('spec')
    parser.add_argument('output')
    args = parser.parse_args()
    generate(json.loads(Path(args.spec).read_text(encoding='utf-8')), args.output)
