---
name: gcp-architecture-diagram
description: Generate editable Google Cloud architecture diagrams in Draw.io format using verified GCP icons. Use for GCP architecture drawing requests.
---

Create a JSON architecture specification, then run the bundled generator to insert icon styles without transcribing encoded images.

1. Identify services, boundaries and request/data flows. Read [layout guidelines](references/layout-guidelines.md).
2. Look up exact service names in `references/icons.json`; read only relevant `references/gcp-icons-*.md` categories for dimensions and styles. Report missing icons; do not invent encoded image data.
3. Write a specification with `containers`, `nodes`, and `edges`. Each node has a unique `id`, exact `service`, optional `label`, `parent`, `x`, and `y`. Coordinates are relative to the parent. Containers have `id`, `label`, `x`, `y`, `width`, `height`, and optional `parent`. Edges have `source`, `target`, and optional `label`.
4. Run `python <skill-directory>/scripts/generate_diagram.py <spec.json> <output.drawio>`.
5. Open the file in Draw.io when a viewer is available. Check icon rendering, readable labels, containment, and connector routing. XML validation alone does not confirm visual quality.

The saved catalog supports offline generation. Refresh only when needed using `python <skill-directory>/scripts/extract_icons.py`; this downloads Draw.io's GCP2 sidebar source and validates every extracted SVG. Source provenance is recorded in `references/source.json`. An upstream syntax change should fail extraction rather than silently drop icons.

Example invocation: `$gcp-architecture-diagram Draw Cloud Load Balancing routing to Cloud Run, with Cloud SQL and Cloud Storage.`

